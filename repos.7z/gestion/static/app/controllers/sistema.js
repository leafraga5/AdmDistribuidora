class Sistema {
    static login(){}
    static checkPermission(){}
    static logout(){ console.log('Cerraste sesión ah re') }
}