class Perfil {
    constructor(){
        this.info = {};
    }
}